import javax.swing.*;

public class EasyKanbanApp {
    private static final Login loginSystem = new Login();
    private static boolean isLoggedIn = false;

    public static void main(String[] args) {
        while (true) {
            int option = Integer.parseInt(JOptionPane.showInputDialog("Welcome to EasyKanban\n1. Register\n2. Login\n3. Quit"));
            switch (option) {
                case 1 -> register();
                case 2 -> login();
                case 3 -> {
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                    System.exit(0);
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid option, please try again.");
            }
        }
    }

    private static void register() {
        String username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");
        String firstName = JOptionPane.showInputDialog("Enter first name:");
        String lastName = JOptionPane.showInputDialog("Enter last name:");
        String registrationMessage = loginSystem.registerUser(username, password, firstName, lastName);
        JOptionPane.showMessageDialog(null, registrationMessage);
    }

    private static void login() {
        String username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");
        if (loginSystem.loginUser(username, password)) {
            isLoggedIn = true;
            JOptionPane.showMessageDialog(null, loginSystem.returnLoginStatus(username));
            mainMenu();
        } else {
            JOptionPane.showMessageDialog(null, "Username or password incorrect, please try again");
        }
    }

    private static void mainMenu() {
        while (isLoggedIn) {
            int option = Integer.parseInt(JOptionPane.showInputDialog("Welcome to EasyKanban\n1. Add Task\n2. Show Report (Coming Soon)\n3. Logout"));
            switch (option) {
                case 1 -> addTask();
                case 2 -> JOptionPane.showMessageDialog(null, "Coming Soon");
                case 3 -> {
                    isLoggedIn = false;
                    JOptionPane.showMessageDialog(null, "Logged out successfully.");
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid option, please try again.");
            }
        }
    }

    private static void addTask() {
        int taskCount = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks you want to add:"));
        for (int i = 0; i < taskCount; i++) {
            String taskName = JOptionPane.showInputDialog("Enter task name:");
            String taskDescription = JOptionPane.showInputDialog("Enter task description (max 50 characters):");
            if (taskDescription.length() > 50) {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters.");
            } else {
                String developerFirstName = JOptionPane.showInputDialog("Enter developer first name:");
                String developerLastName = JOptionPane.showInputDialog("Enter developer last name:");
                int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter task duration (in hours):"));
                String taskStatus = JOptionPane.showInputDialog("Enter task status (To Do, Doing, Done):");

                String taskId = taskName.substring(0, 2).toUpperCase() + ":" + i + ":" + developerLastName.substring(developerLastName.length() - 3).toUpperCase();
                String taskDetails = String.format("Task Status: %s\nDeveloper Details: %s %s\nTask Number: %d\nTask Name: %s\nTask Description: %s\nTask ID: %s\nDuration: %d hours",
                        taskStatus, developerFirstName, developerLastName, i, taskName, taskDescription, taskId, taskDuration);
                JOptionPane.showMessageDialog(null, "Task successfully captured:\n" + taskDetails);
            }
        }
    }
}
