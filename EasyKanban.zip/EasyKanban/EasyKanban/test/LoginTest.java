import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class LoginTest {
    private Login login;

    @BeforeEach
    public void setUp() {
        login = new Login();
    }

    @Test
    public void testCheckUserName() {
        assertTrue(login.checkUserName("user_"));
        assertFalse(login.checkUserName("username"));
        assertFalse(login.checkUserName("user"));
        assertFalse(login.checkUserName("user__"));
    }

    @Test
    public void testCheckPasswordComplexity() {
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
        assertFalse(login.checkPasswordComplexity("password"));
        assertFalse(login.checkPasswordComplexity("Password1"));
        assertFalse(login.checkPasswordComplexity("password@1"));
        assertFalse(login.checkPasswordComplexity("Password!"));
    }

    @Test
    public void testRegisterUser() {
        assertEquals("Username and password successfully captured.", login.registerUser("user_", "Ch&&sec@ke99!", "John", "Doe"));
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.", login.registerUser("username", "Ch&&sec@ke99!", "John", "Doe"));
        assertEquals("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.", login.registerUser("user_", "password", "John", "Doe"));
    }

    @Test
    public void testLoginUser() {
        login.registerUser("user_", "Ch&&sec@ke99!", "John", "Doe");
        assertTrue(login.loginUser("user_", "Ch&&sec@ke99!"));
        assertFalse(login.loginUser("user_", "wrongpassword"));
        assertFalse(login.loginUser("wronguser", "Ch&&sec@ke99!"));
    }

    @Test
    public void testReturnLoginStatus() {
        login.registerUser("user_", "Ch&&sec@ke99!", "John", "Doe");
        assertEquals("Welcome John Doe, it is great to see you again.", login.returnLoginStatus("user_"));
        assertEquals("Username or password incorrect, please try again.", login.returnLoginStatus("wronguser"));
    }
}
